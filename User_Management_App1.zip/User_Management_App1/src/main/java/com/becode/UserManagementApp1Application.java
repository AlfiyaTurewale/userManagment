package com.becode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.becode.controller," + "com.becode.service")
public class UserManagementApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementApp1Application.class, args);
		System.out.println("successfully excute");
	}

}
