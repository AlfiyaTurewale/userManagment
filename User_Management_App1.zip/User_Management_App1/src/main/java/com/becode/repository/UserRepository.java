package com.becode.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.becode.model.UserDtls;

public interface UserRepository  extends JpaRepository<UserDtls, Integer>{

	
	public boolean existByEmail(String email);
}
