package com.becode.service;

import com.becode.model.UserDtls;

public interface UserService {

	public UserDtls createUser(UserDtls user);
	
	public boolean checkEmail(String email);
}
