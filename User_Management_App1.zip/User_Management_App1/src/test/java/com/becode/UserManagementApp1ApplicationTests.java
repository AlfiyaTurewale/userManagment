package com.becode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
